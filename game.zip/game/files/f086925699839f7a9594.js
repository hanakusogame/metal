function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション。省略された場合、 {modified: target.modified, destroyed: target.destroyed} が与えられた時と同様の処理を行う。
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを完了させる。詳細は `Tween#complete()`の説明を参照。
         */


        Timeline.prototype.completeAll = function () {
          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween.complete();
            }
          }

          this.clear();
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを取り消す。詳細は `Tween#cancel()`の説明を参照。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */


        Timeline.prototype.cancelAll = function (revert) {
          if (revert === void 0) {
            revert = false;
          }

          if (!revert) {
            this.clear();
            return;
          }

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween.cancel(true);
            }
          }

          this.clear();
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = undefined;

          if (option && option.modified) {
            this._modifiedHandler = option.modified;
          } else if (target && target.modified) {
            this._modifiedHandler = target.modified;
          }

          this._destroyedHandler = undefined;

          if (option && option.destroyed) {
            this._destroyedHandler = option.destroyed;
          } else if (target && target.destroyed) {
            this._destroyedHandler = target.destroyed;
          }

          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this._initialProp = {};
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * このTweenに追加されたすべてのアクションを即座に完了する。
         * `Tween#loop`が`true`の場合、ループの終端までのアクションがすべて実行される。
         */


        Tween.prototype.complete = function () {
          for (var i = this._stepIndex; i < this._steps.length; ++i) {
            for (var j = 0; j < this._steps[i].length; ++j) {
              var action = this._steps[i][j];

              if (!action.initialized) {
                this._initAction(action);
              }

              var keys = Object.keys(action.goal);

              for (var k = 0; k < keys.length; ++k) {
                var key = keys[k];
                this._target[key] = action.goal[key];
              }

              if (action.type === ActionType.Call && typeof action.func === "function") {
                action.func.call(this._target);
              } else if (action.type === ActionType.Cue && action.cue) {
                for (var k = 0; k < action.cue.length; ++k) {
                  action.cue[k].func.call(this._target);
                }
              } else if (action.type === ActionType.Every && typeof action.func === "function") {
                action.func.call(this._target, action.duration, 1);
              }
            }
          }

          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;

          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * このTweenに追加されたすべてのアクションを取り消す。
         * `revert`を`true` にした場合、ターゲットのプロパティをアクション開始前に戻す。
         * ただし`Tween#call()`や`Tween#every()`により変更されたプロパティは戻らない点に注意。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */


        Tween.prototype.cancel = function (revert) {
          if (revert === void 0) {
            revert = false;
          }

          if (revert) {
            var keys = Object.keys(this._initialProp);

            for (var i = 0; i < keys.length; ++i) {
              var key = keys[i];
              this._target[key] = this._initialProp[key];
            }
          }

          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;

          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * アニメーションが終了しているかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.isFinished = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex !== 0 && this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.isFinished() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j]; // アクションにより undefined が指定されるケースと初期値を区別するため Object.prototype.hasOwnProperty() を利用
                  // (number以外が指定されるケースは存在しないが念の為)

                  if (!this._initialProp.hasOwnProperty(key)) {
                    this._initialProp[key] = this._target[key];
                  }

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _initialProp: this._initialProp,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;
          this._initialProp = serializedState._initialProp;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 1,
      "./Easing": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 2,
      "./Timeline": 3,
      "./Tween": 4
    }],
    6: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics = function extendStatics(d, b) {
          _extendStatics = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics(d, b);
        };

        return function (d, b) {
          _extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Button = void 0;

      var Button =
      /** @class */
      function (_super) {
        __extends(Button, _super);

        function Button(scene, s, x, y, w, h) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          if (w === void 0) {
            w = 100;
          }

          if (h === void 0) {
            h = 50;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: w,
            height: h,
            x: x,
            y: y,
            touchable: true
          }) || this;

          _this.num = 0;

          _this.chkEnable = function (ev) {
            return true;
          }; // this.pushEvent = () => {};


          if (Button.font == null) {
            Button.font = new g.DynamicFont({
              game: g.game,
              fontFamily: g.FontFamily.Monospace,
              size: 32
            });
          }

          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: w - 4,
            height: h - 4,
            cssColor: "white"
          });

          _this.append(base);

          _this.label = new g.Label({
            scene: scene,
            font: Button.font,
            text: s[0],
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: w - 4
          });
          _this.label.y = (h - 4 - _this.label.height) / 2;

          _this.label.modified();

          base.append(_this.label);

          _this.onPointDown.add(function (ev) {
            if (!_this.chkEnable(ev)) return;
            base.cssColor = "gray";
            base.modified();

            if (s.length !== 1) {
              _this.num = (_this.num + 1) % s.length;
              _this.label.text = s[_this.num];

              _this.label.invalidate();
            }
          });

          _this.onPointUp.add(function (ev) {
            base.cssColor = "white";
            base.modified();

            _this.pushEvent(ev);
          });

          return _this;
        }

        return Button;
      }(g.FilledRect);

      exports.Button = Button;
    }, {}],
    7: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics2 = function extendStatics(d, b) {
          _extendStatics2 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics2(d, b);
        };

        return function (d, b) {
          _extendStatics2(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Config = void 0;

      var Button_1 = require("./Button"); //設定画面クラス


      var Config =
      /** @class */
      function (_super) {
        __extends(Config, _super);

        function Config(scene, x, y) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: 250,
            height: 250,
            x: x,
            y: y,
            scaleX: 2.0,
            scaleY: 2.0,
            touchable: true
          }) || this;

          _this.num = 0;
          _this.volumes = [0.5, 0.8];

          _this.chkEnable = function (ev) {
            return true;
          }; // const events = [this.bgmEvent, this.seEvent];


          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: "monospace",
            size: 32
          });
          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: _this.width - 4,
            height: _this.height - 4,
            cssColor: "white"
          });

          _this.append(base);

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "設定",
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: "center",
            width: 250
          }));
          var line = new g.FilledRect({
            scene: scene,
            x: 5,
            y: 30,
            width: 235,
            height: 2,
            cssColor: "#000000"
          });
          base.append(line);
          var strVol = ["ＢＧＭ", "効果音"];

          var _loop_1 = function _loop_1(i) {
            base.append(new g.Label({
              scene: scene,
              font: font,
              text: strVol[i],
              fontSize: 24,
              textColor: "black",
              x: 10,
              y: 50 + 50 * i
            }));
            var sprVol = new g.FrameSprite({
              scene: scene,
              src: scene.assets.volume,
              width: 32,
              height: 32,
              x: 90,
              y: 50 + 50 * i,
              frames: [0, 1]
            });
            base.append(sprVol);
            var baseVol = new g.E({
              scene: scene,
              x: 130,
              y: 50 + 50 * i,
              width: 110,
              height: 32,
              touchable: true
            });
            base.append(baseVol);
            var lineVol = new g.FilledRect({
              scene: scene,
              x: 0,
              y: 13,
              width: 110,
              height: 6,
              cssColor: "gray"
            });
            baseVol.append(lineVol);
            var cursorVol = new g.FilledRect({
              scene: scene,
              x: 110 * this_1.volumes[i] - 7,
              y: 0,
              width: 15,
              height: 32,
              cssColor: "#000000"
            });
            baseVol.append(cursorVol);
            var flgMute = false;
            baseVol.onPointMove.add(function (e) {
              var posX = e.point.x + e.startDelta.x / 2;
              if (posX < 7) posX = 7;
              if (posX > 103) posX = 103;
              cursorVol.x = posX - 7;
              cursorVol.modified();
              flgMute = posX - 7 === 0;
            });
            baseVol.onPointUp.add(function (e) {
              if (flgMute) {
                sprVol.frameNumber = 1;
              } else {
                sprVol.frameNumber = 0;
              }

              sprVol.modified();
              _this.volumes[i] = cursorVol.x / 110;

              if (i === 0 && _this.bgmEvent !== undefined) {
                _this.bgmEvent(_this.volumes[i]);
              }
            });
          };

          var this_1 = this;

          for (var i = 0; i < 2; i++) {
            _loop_1(i);
          }

          var colors = ["gray", "black", "white", "green", "navy"];
          var colorNum = 0; // 背景色

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "背景色",
            fontSize: 24,
            textColor: "black",
            x: 10,
            y: 150
          }));
          base.append(new g.FilledRect({
            scene: scene,
            x: 130,
            y: 150,
            width: 110,
            height: 40,
            cssColor: "#000000"
          }));
          var sprColor = new g.FilledRect({
            scene: scene,
            x: 132,
            y: 152,
            width: 106,
            height: 36,
            cssColor: "gray",
            touchable: true
          });
          base.append(sprColor);
          sprColor.onPointDown.add(function (e) {
            colorNum = (colorNum + 1) % colors.length;
            sprColor.cssColor = colors[colorNum];
            sprColor.modified();

            if (_this.bg) {
              _this.bg.cssColor = colors[colorNum];

              _this.bg.modified();
            }
          }); // ランキング表示

          var btnRank = new Button_1.Button(scene, ["ランキング"], 2, 198, 130, 45);
          base.append(btnRank);

          btnRank.pushEvent = function () {
            if (typeof window !== "undefined" && window.RPGAtsumaru) {
              window.RPGAtsumaru.scoreboards.display(1);
            }
          }; // 閉じる


          var btnClose = new Button_1.Button(scene, ["閉じる"], 138, 198, 105, 45);
          base.append(btnClose);

          btnClose.pushEvent = function () {
            _this.hide();
          };

          return _this;
        }

        return Config;
      }(g.FilledRect);

      exports.Config = Config;
    }, {
      "./Button": 6
    }],
    8: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics3 = function extendStatics(d, b) {
          _extendStatics3 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics3(d, b);
        };

        return function (d, b) {
          _extendStatics3(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Enemy = void 0; //敵クラス

      var Enemy =
      /** @class */
      function (_super) {
        __extends(Enemy, _super);

        function Enemy(base) {
          var _this = _super.call(this, {
            scene: g.game.scene(),
            x: g.game.width,
            y: 0,
            parent: base
          }) || this;

          _this.op = 0.0;
          _this.score = 200;
          _this.order = 0;
          _this.life = 100;
          _this.speed = 10; //ダメージを与えられたとき

          _this.setDamage = function (num) {
            _this.life -= num;
            _this.opacity = 0.5;

            _this.modified();

            g.game.scene().setTimeout(function () {
              _this.opacity = 1.0;

              _this.modified();
            }, 10);

            if (_this.life <= 0) {
              if (_this.sprImageDie) {
                _this.sprImage.hide();

                _this.sprImageDie.show();

                _this.die();
              } else {
                _this.destroy();
              }

              g.game.scene().addScore(_this.score);
            }

            return _this.life > 0;
          }; //ショットとのあたり判定


          _this.collision = function (shot) {
            if (_this.life <= 0 || !_this.collisionArea) return false;
            var c = _this.collisionArea;
            var p = c.localToGlobal({
              x: 0,
              y: 0
            });
            return g.Collision.intersect(shot.x, shot.y, shot.width, shot.height, p.x, p.y, c.width, c.height);
          };

          _this.scene = g.game.scene();
          _this.speed = g.game.random.get(6, 12);

          _this.die = function () {
            return;
          };

          _this.onUpdate.add(function () {
            _this.x -= _this.speed;

            _this.modified();

            if (_this.x + _this.sprImage.width < 0) {
              _this.destroy();
            }
          });

          return _this;
        }

        return Enemy;
      }(g.E);

      exports.Enemy = Enemy;
    }, {}],
    9: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics4 = function extendStatics(d, b) {
          _extendStatics4 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics4(d, b);
        };

        return function (d, b) {
          _extendStatics4(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Fighter = void 0;

      var Enemy_1 = require("./Enemy"); //戦闘機クラス


      var Fighter =
      /** @class */
      function (_super) {
        __extends(Fighter, _super);

        function Fighter(base) {
          var _this = _super.call(this, base) || this;

          _this.order = 0;
          _this.y = g.game.random.get(-250, -100);

          _this.modified();

          _this.score = 2000;
          _this.life = 80;
          var scene = g.game.scene();
          _this.sprImage = new g.Sprite({
            scene: scene,
            x: 0,
            y: 0,
            src: g.game.scene().asset.getImageById("fighter"),
            parent: _this
          });
          _this.sprImageDie = new g.Sprite({
            scene: scene,
            x: 0,
            y: 0,
            src: g.game.scene().asset.getImageById("fighter2"),
            parent: _this
          });

          _this.sprImageDie.hide();

          _this.collisionArea = new g.FilledRect({
            scene: scene,
            x: 200,
            y: 200,
            width: 250,
            height: 120,
            cssColor: "yellow",
            opacity: _this.op,
            parent: _this
          });
          var yy = 5;

          _this.onUpdate.add(function () {
            if (_this.life <= 0) {
              _this.y += 20;
            } else {
              yy -= 0.2;
              _this.y += yy;
              _this.angle += 0.2;
            }

            _this.modified();
          });

          _this.die = function () {
            for (var i = 0; i < 3; i++) {
              var effect = new g.FrameSprite({
                scene: scene,
                src: scene.asset.getImageById("effect"),
                parent: _this,
                x: 200 * i,
                y: -200 + g.game.random.get(0, 200),
                width: 128,
                height: 256,
                frames: [0, 1, 2, 3, 4, 5, 6, 6, 7],
                frameNumber: 0,
                loop: false,
                interval: 100,
                scaleX: 3,
                scaleY: 3
              });
              effect.start();
            }

            _this.speed = _this.speed / 2;

            _this.scene.playSound("bomb");
          };

          _this.speed = g.game.random.get(24, 32);
          return _this;
        }

        return Fighter;
      }(Enemy_1.Enemy);

      exports.Fighter = Fighter;
    }, {
      "./Enemy": 8
    }],
    10: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics5 = function extendStatics(d, b) {
          _extendStatics5 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics5(d, b);
        };

        return function (d, b) {
          _extendStatics5(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Sniper = void 0;

      var Enemy_1 = require("./Enemy"); //スナイパークラス


      var Sniper =
      /** @class */
      function (_super) {
        __extends(Sniper, _super);

        function Sniper(base, x, y) {
          var _this = _super.call(this, base) || this;

          _this.order = 8;
          _this.x = x;
          _this.y = y;

          _this.modified();

          var scene = g.game.scene();
          _this.score = 300;
          _this.life = 30;
          var spr = new g.FrameSprite({
            scene: scene,
            x: 0,
            y: 0,
            width: 128,
            height: 128,
            src: g.game.scene().asset.getImageById("sniper"),
            parent: _this,
            frames: [0],
            frameNumber: 0
          });
          var effect = new g.Sprite({
            scene: scene,
            src: scene.asset.getImageById("effect2"),
            x: -30,
            y: 100,
            width: 50,
            height: 50,
            srcX: 50,
            angle: -45,
            parent: _this
          });
          effect.hide();
          _this.sprImage = spr;
          var posDieY = 450 + g.game.random.get(0, 100);
          var yy = -20;

          _this.onUpdate.add(function () {
            if (_this.life <= 0) {
              if (_this.y < posDieY) {
                yy += 2;
                _this.y += yy;
              }
            } else {
              if (g.game.random.get(0, 20) === 0) {
                //攻撃
                effect.show();
                scene.setTimeout(function () {
                  effect.hide();
                }, 100);
                scene.playSound("se_shot2");
              }
            }

            _this.modified();
          });

          var sprDie = new g.FrameSprite({
            scene: scene,
            x: 0,
            y: 0,
            width: 128,
            height: 128,
            src: g.game.scene().asset.getImageById("soldier"),
            parent: _this,
            frames: [3, 4, 5],
            frameNumber: 0,
            interval: 200,
            loop: false
          });
          sprDie.hide();
          _this.sprImageDie = sprDie;
          _this.collisionArea = new g.FilledRect({
            scene: scene,
            x: 16,
            y: 16,
            width: 96,
            height: 96,
            cssColor: "yellow",
            opacity: _this.op,
            parent: _this
          });

          _this.die = function () {
            sprDie.start();

            _this.scene.playSound("guaa");

            effect.hide();
          };

          _this.speed = 2;
          return _this;
        }

        return Sniper;
      }(Enemy_1.Enemy);

      exports.Sniper = Sniper;
    }, {
      "./Enemy": 8
    }],
    11: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics6 = function extendStatics(d, b) {
          _extendStatics6 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics6(d, b);
        };

        return function (d, b) {
          _extendStatics6(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Soldier = void 0;

      var Enemy_1 = require("./Enemy"); //ソルジャークラス


      var Soldier =
      /** @class */
      function (_super) {
        __extends(Soldier, _super);

        function Soldier(base) {
          var _this = _super.call(this, base) || this;

          _this.order = 1;
          _this.y = g.game.random.get(400, 550);

          _this.modified();

          var scene = g.game.scene();
          _this.score = 200;
          _this.life = 30;
          var spr = new g.FrameSprite({
            scene: scene,
            x: 0,
            y: 0,
            width: 128,
            height: 128,
            src: g.game.scene().asset.getImageById("soldier"),
            parent: _this,
            frames: [0, 2, 1, 2],
            frameNumber: 0,
            interval: 100
          });
          spr.start();
          _this.sprImage = spr;
          var effect = new g.Sprite({
            scene: scene,
            src: scene.asset.getImageById("effect2"),
            x: -30,
            y: 20,
            width: 50,
            height: 50,
            srcX: 50,
            parent: _this
          });
          effect.hide();
          var sprDie = new g.FrameSprite({
            scene: scene,
            x: 0,
            y: 0,
            width: 128,
            height: 128,
            src: g.game.scene().asset.getImageById("soldier"),
            parent: _this,
            frames: [3, 4, 5],
            frameNumber: 0,
            interval: 200,
            loop: false
          });
          sprDie.hide();
          _this.sprImageDie = sprDie;

          _this.onUpdate.add(function () {
            if (_this.life > 0) {
              if (g.game.random.get(0, 20) === 0) {
                //攻撃
                effect.show();
                scene.setTimeout(function () {
                  effect.hide();
                }, 100);
                scene.playSound("se_shot2");
              }
            }

            _this.modified();
          });

          _this.collisionArea = new g.FilledRect({
            scene: scene,
            x: 16,
            y: 16,
            width: 96,
            height: 96,
            cssColor: "yellow",
            opacity: _this.op,
            parent: _this
          });

          _this.die = function () {
            sprDie.start();
            _this.speed = 2;

            _this.scene.playSound("guaa");

            effect.hide();
          };

          _this.speed = g.game.random.get(4, 8);
          return _this;
        }

        return Soldier;
      }(Enemy_1.Enemy);

      exports.Soldier = Soldier;
    }, {
      "./Enemy": 8
    }],
    12: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics7 = function extendStatics(d, b) {
          _extendStatics7 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics7(d, b);
        };

        return function (d, b) {
          _extendStatics7(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Tank = void 0;

      var Enemy_1 = require("./Enemy"); //戦車クラス


      var Tank =
      /** @class */
      function (_super) {
        __extends(Tank, _super);

        function Tank(base) {
          var _this = _super.call(this, base) || this;

          _this.order = 1;
          _this.y = g.game.random.get(0, 230);

          _this.modified();

          _this.score = 1500;
          _this.life = 200;
          var scene = g.game.scene(); //画像

          _this.sprImage = new g.Sprite({
            scene: scene,
            x: 0,
            y: 0,
            src: g.game.scene().asset.getImageById("tank"),
            parent: _this
          }); //攻撃してる風エフェクト

          var effect = new g.Sprite({
            scene: scene,
            src: scene.asset.getImageById("effect2"),
            x: -50,
            y: 170,
            width: 50,
            height: 50,
            srcX: 50,
            scaleX: 2,
            scaleY: 2,
            parent: _this
          });
          effect.hide(); //壊れた時の画像

          _this.sprImageDie = new g.Sprite({
            scene: scene,
            x: 0,
            y: 0,
            src: g.game.scene().asset.getImageById("tank2"),
            parent: _this
          });

          _this.sprImageDie.hide(); //当たり判定用


          _this.collisionArea = new g.FilledRect({
            scene: scene,
            x: 350,
            y: 200,
            width: 250,
            height: 120,
            cssColor: "yellow",
            opacity: _this.op,
            parent: _this
          });

          _this.onUpdate.add(function () {
            if (_this.life > 0) {
              if (g.game.random.get(0, 100) === 0) {
                //攻撃
                effect.show();
                scene.setTimeout(function () {
                  effect.hide();
                }, 200);
                scene.playSound("se_shot3");
              }
            }

            _this.modified();
          });

          _this.die = function () {
            var _loop_1 = function _loop_1(i) {
              var effect_1 = new g.FrameSprite({
                scene: scene,
                src: scene.asset.getImageById("effect"),
                parent: _this,
                x: 200 * i,
                y: -300 + g.game.random.get(0, 200),
                width: 128,
                height: 256,
                frames: [0, 1, 2, 3, 4, 5, 6, 6, 7, 7, 8, 9, 8, 9],
                frameNumber: 0,
                loop: false,
                interval: 150,
                scaleX: 3,
                scaleY: 3
              });
              effect_1.start();
              scene.setTimeout(function () {
                effect_1.frames = [8, 9];
                effect_1.loop = true;
                effect_1.interval = 500;
                effect_1.frameNumber = 0;
                effect_1.start();
              }, 1800);
            };

            for (var i = 0; i < 3; i++) {
              _loop_1(i);
            }

            _this.speed = 2;

            _this.scene.playSound("bomb");

            effect.hide();
          };

          _this.speed = g.game.random.get(3, 5);
          return _this;
        }

        return Tank;
      }(Enemy_1.Enemy);

      exports.Tank = Tank;
    }, {
      "./Enemy": 8
    }],
    13: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics8 = function extendStatics(d, b) {
          _extendStatics8 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics8(d, b);
        };

        return function (d, b) {
          _extendStatics8(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Wall = void 0;

      var Enemy_1 = require("./Enemy");

      var Sniper_1 = require("./Sniper"); //廃墟クラス


      var Wall =
      /** @class */
      function (_super) {
        __extends(Wall, _super);

        function Wall(base) {
          var _this = _super.call(this, base) || this;

          _this.order = 9;
          _this.y = g.game.random.get(-50, 0);

          _this.modified();

          _this.score = 300;
          _this.life = 200;
          var scene = g.game.scene(); //画像

          _this.sprImage = new g.Sprite({
            scene: scene,
            x: 0,
            y: 0,
            src: g.game.scene().asset.getImageById("wall"),
            parent: _this
          }); //スナイパー設置

          var snipers = [];
          snipers[0] = new Sniper_1.Sniper(base, _this.x + 150, _this.y + 230);
          snipers[1] = new Sniper_1.Sniper(base, _this.x + 430, _this.y + 230);

          _this.onUpdate.add(function () {
            for (var i = 0; i < snipers.length; i++) {
              if (g.game.random.get(0, 100) === 0 && snipers[i].life <= 0) {
                snipers[i] = new Sniper_1.Sniper(base, _this.x + 150 + 280 * i, _this.y + 230);
              }
            }

            ;
          });

          _this.speed = 2;
          return _this;
        }

        return Wall;
      }(Enemy_1.Enemy);

      exports.Wall = Wall;
    }, {
      "./Enemy": 8,
      "./Sniper": 10
    }],
    14: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics9 = function extendStatics(d, b) {
          _extendStatics9 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics9(d, b);
        };

        return function (d, b) {
          _extendStatics9(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Zero = void 0;

      var Enemy_1 = require("./Enemy"); //零戦クラス


      var Zero =
      /** @class */
      function (_super) {
        __extends(Zero, _super);

        function Zero(base) {
          var _this = _super.call(this, base) || this;

          _this.order = 0;
          _this.y = g.game.random.get(-100, 250);

          _this.modified();

          _this.speed = g.game.random.get(15, 30);
          _this.score = 1000;
          _this.life = 80;
          var scene = g.game.scene();
          _this.sprImage = new g.Sprite({
            scene: scene,
            x: 0,
            y: 0,
            src: g.game.scene().asset.getImageById("zero"),
            parent: _this
          });
          _this.sprImageDie = new g.Sprite({
            scene: scene,
            x: 0,
            y: 0,
            src: g.game.scene().asset.getImageById("fighter2"),
            parent: _this
          });

          _this.sprImageDie.hide();

          _this.collisionArea = new g.FilledRect({
            scene: scene,
            x: 150,
            y: 50,
            width: 150,
            height: 120,
            cssColor: "yellow",
            opacity: _this.op,
            parent: _this
          });

          _this.onUpdate.add(function () {
            if (_this.life <= 0) {
              _this.y += 20;
            }

            _this.modified();
          });

          _this.die = function () {
            for (var i = 0; i < 3; i++) {
              var effect = new g.FrameSprite({
                scene: scene,
                src: scene.asset.getImageById("effect"),
                parent: _this,
                x: 200 * i,
                y: -200 + g.game.random.get(0, 200),
                width: 128,
                height: 256,
                frames: [0, 1, 2, 3, 4, 5, 6, 6, 7],
                frameNumber: 0,
                loop: false,
                interval: 100,
                scaleX: 3,
                scaleY: 3
              });
              effect.start();
            }

            _this.speed = _this.speed / 2;

            _this.scene.playSound("bomb");
          };

          return _this;
        }

        return Zero;
      }(Enemy_1.Enemy);

      exports.Zero = Zero;
    }, {
      "./Enemy": 8
    }],
    15: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics10 = function extendStatics(d, b) {
          _extendStatics10 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics10(d, b);
        };

        return function (d, b) {
          _extendStatics10(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MainGame = void 0;

      var Fighter_1 = require("./Enemy/Fighter");

      var Soldier_1 = require("./Enemy/Soldier");

      var Tank_1 = require("./Enemy/Tank");

      var Wall_1 = require("./Enemy/Wall");

      var Zero_1 = require("./Enemy/Zero");

      var Player_1 = require("./Player"); //ゲームクラス


      var MainGame =
      /** @class */
      function (_super) {
        __extends(MainGame, _super);

        function MainGame() {
          var _this = this;

          var scene = g.game.scene();
          _this = _super.call(this, {
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            touchable: true
          }) || this; //背景

          var bgBase = new g.E({
            scene: scene,
            scaleX: 3,
            scaleY: 3,
            parent: _this
          });

          for (var i = 0; i < 3; i++) {
            new g.Sprite({
              scene: scene,
              src: scene.asset.getImageById("bg"),
              x: 640 * i,
              y: 0,
              parent: bgBase
            });
          } //地面を生成


          var floorSize = 256;
          var collisionFloor;

          var _loop_1 = function _loop_1(i) {
            var floor = new g.FilledRect({
              scene: scene,
              x: floorSize * i,
              y: g.game.height - 128 + g.game.random.get(0, 50),
              width: floorSize,
              height: 128,
              cssColor: "white",
              parent: this_1
            });
            new g.Sprite({
              scene: scene,
              x: 0,
              y: -128,
              width: floorSize,
              height: 512,
              src: scene.asset.getImageById("floor"),
              parent: floor
            });
            floor.onUpdate.add(function () {
              floor.x -= 2;

              if (floor.x <= -floorSize) {
                floor.x = g.game.width + floorSize;
              }

              var cx = player.x + player.width / 2; //中央

              if (floor.x < cx && floor.x + floorSize > cx) {
                collisionFloor = floor;
              }

              floor.modified();
            });
          };

          var this_1 = this;

          for (var i = 0; i < 7; i++) {
            _loop_1(i);
          } //敵設置用エンティティ


          var enemyBase = new g.E({
            scene: scene,
            parent: _this
          }); // プレイヤーを生成

          var player = new Player_1.Player(_this);
          player.onUpdate.add(function () {
            player.y += 16;

            if (collisionFloor && player.y > collisionFloor.y - player.height) {
              player.y = collisionFloor.y - player.height;
            }
          });
          var isPush = false; //タッチされているか

          var radian = 0; //ショットの角度
          // 攻撃風エフェクト

          var effect = new g.Sprite({
            scene: scene,
            src: scene.asset.getImageById("effect2"),
            width: 50,
            height: 50,
            srcY: 50,
            scaleX: 2,
            scaleY: 2,
            parent: _this
          });
          effect.hide(); //角度取得

          var setAngle = function setAngle(x, y) {
            var px = player.x + player.width / 2;
            var py = player.y + player.height / 2;
            radian = Math.atan2(y - py, x - px);
          }; //タッチイベント


          _this.onPointDown.add(function (e) {
            isPush = true;
            setAngle(e.point.x, e.point.y);
          });

          _this.onPointMove.add(function (e) {
            setAngle(e.point.x + e.startDelta.x, e.point.y + e.startDelta.y);
          });

          _this.onPointUp.add(function (e) {
            isPush = false;
            setAngle(e.point.x + e.startDelta.x, e.point.y + e.startDelta.y);
          }); //メインループ


          var loopCnt = 0;

          _this.onUpdate.add(function () {
            bgBase.x -= 1;
            bgBase.modified();
            player.werpon.angle = radian * 180 / Math.PI;
            player.werpon.modified();

            if (loopCnt % 4 === 0 && isPush && scene.isStart) {
              //ショットを生成
              var shot_1 = new g.Sprite({
                scene: scene,
                x: player.x + player.width / 2 - loopCnt % 8 * 5,
                y: player.y + player.height / 2 - loopCnt % 8 * 5,
                src: scene.asset.getImageById("shot"),
                angle: radian * 180 / Math.PI,
                anchorX: 0.5,
                anchorY: 0.5,
                parent: _this
              }); //移動量算出

              var speed = 50;
              var mx_1 = speed * Math.cos(radian);
              var my_1 = speed * Math.sin(radian); //移動

              shot_1.x += mx_1 * 4;
              shot_1.y += my_1 * 4;
              shot_1.modified();
              shot_1.onUpdate.add(function () {
                //移動
                shot_1.x += mx_1;
                shot_1.y += my_1;
                shot_1.modified();
                var isDelete = false; //画面外に出たら削除

                if (shot_1.x + shot_1.width < 0 || shot_1.y + shot_1.width < 0 || shot_1.x - shot_1.width > g.game.width || shot_1.y - shot_1.width > g.game.height) {
                  isDelete = true;
                } //敵との当たり判定


                enemyBase.children.forEach(function (e) {
                  var enemy = e;

                  if (enemy.collision(shot_1)) {
                    enemy.setDamage(10);
                    isDelete = true;
                  }
                });

                if (isDelete) {
                  shot_1.destroy();
                }
              });
              scene.playSound("se_shot");
            }

            if (loopCnt % 60 === 0) {
              //敵を生成
              var listEnemy = [Fighter_1.Fighter, Tank_1.Tank, Soldier_1.Soldier, Zero_1.Zero];
              var num = g.game.random.get(0, listEnemy.length - 1);
              new listEnemy[num](enemyBase);
            }

            if (loopCnt % 900 === 0) {
              new Wall_1.Wall(enemyBase);
            } //並べ替え


            enemyBase.children.sort(function (a, b) {
              var aa = a;
              var bb = b;
              return aa.order * -10000 + aa.y + aa.sprImage.height - (bb.order * -10000 + bb.y + bb.sprImage.height);
            }); //エフェクト表示

            if (g.game.random.get(0, 30) === 0) {
              effect.x = g.game.random.get(0, 300);
              effect.y = g.game.random.get(500, 640);
              effect.modified();
              effect.show();
              scene.setTimeout(function () {
                effect.hide();
              }, 100);
            }

            loopCnt++;
          });

          return _this;
        }

        return MainGame;
      }(g.E);

      exports.MainGame = MainGame;
    }, {
      "./Enemy/Fighter": 9,
      "./Enemy/Soldier": 11,
      "./Enemy/Tank": 12,
      "./Enemy/Wall": 13,
      "./Enemy/Zero": 14,
      "./Player": 17
    }],
    16: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics11 = function extendStatics(d, b) {
          _extendStatics11 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics11(d, b);
        };

        return function (d, b) {
          _extendStatics11(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MainScene = void 0;

      var tl = require("@akashic-extension/akashic-timeline");

      var Button_1 = require("./Button");

      var Config_1 = require("./Config");

      var MainGame_1 = require("./MainGame");

      var MainScene =
      /** @class */
      function (_super) {
        __extends(MainScene, _super);

        function MainScene(param) {
          var _this = _super.call(this, {
            game: g.game,
            // このシーンで利用するアセットのIDを列挙し、シーンに通知します
            assetIds: ["title", "score", "time", "start", "bg", "player", "werpon", "shot", "tank", "tank2", "fighter", "fighter2", "soldier", "zero", "wall", "sniper", "floor", "effect", "effect2", "glyph", "number", "number_red", "config", "volume", "bgm", "se_start", "se_timeup", "se_shot", "se_shot2", "se_shot3", "bomb", "guaa"]
          }) || this;

          _this.isStart = false;
          var timeline = new tl.Timeline(_this);
          var timeLimit = 120; // 制限時間

          var isDebug = false;
          var time = 0;
          var version = "var. 1.02"; // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います

          g.game.vars.gameState = {
            score: 0
          };

          _this.onLoad.add(function () {
            var bgm = _this.asset.getAudioById("bgm").play();

            bgm.changeVolume(isDebug ? 0.0 : 0.3); //背景

            var bg = new g.FilledRect({
              scene: _this,
              width: g.game.width,
              height: g.game.height,
              cssColor: "gray",
              parent: _this,
              opacity: param.isAtsumaru || isDebug ? 1.0 : 0.5
            });
            var base = new g.E({
              scene: _this,
              parent: _this
            });
            var maingame; // タイトル

            var sprTitle = new g.Sprite({
              scene: _this,
              src: _this.asset.getImageById("title"),
              x: 0
            });

            _this.append(sprTitle);

            var font = new g.DynamicFont({
              game: g.game,
              fontFamily: "monospace",
              size: 24
            }); //バージョン情報

            new g.Label({
              scene: _this,
              font: font,
              fontSize: 24,
              text: version,
              parent: sprTitle
            });
            timeline.create(sprTitle, {
              modified: sprTitle.modified
            }).wait(isDebug ? 1000 : 8000).moveBy(-1280, 0, 200).call(function () {
              init();
            });

            var init = function init() {
              // 上で生成した font.png と font_glyphs.json に対応するアセットを取得
              var fontGlyphAsset = _this.asset.getTextById("glyph"); // テキストアセット (JSON) の内容をオブジェクトに変換


              var glyphInfo = JSON.parse(fontGlyphAsset.data); // ビットマップフォントを生成

              var font = new g.BitmapFont({
                src: _this.asset.getImageById("number"),
                glyphInfo: glyphInfo
              }); // ビットマップフォントを生成

              var fontRed = new g.BitmapFont({
                src: _this.asset.getImageById("number_red"),
                glyphInfo: glyphInfo
              });
              new g.Sprite({
                scene: _this,
                src: _this.asset.getImageById("score"),
                width: 192,
                height: 64,
                x: 640,
                y: 10,
                parent: _this
              }); // スコア表示用のラベル

              var scoreLabel = new g.Label({
                scene: _this,
                text: "0P",
                font: font,
                fontSize: 32,
                x: 750,
                y: 10,
                width: 450,
                widthAutoAdjust: false,
                textAlign: "right",
                parent: _this
              }); //時間の時計アイコン

              new g.Sprite({
                scene: _this,
                src: _this.asset.getImageById("time"),
                x: 5,
                y: 5,
                parent: _this
              }); // 残り時間表示用ラベル

              var timeLabel = new g.Label({
                scene: _this,
                text: "0",
                font: font,
                fontSize: 32,
                x: 105,
                y: 10,
                parent: _this
              }); //点滅用

              var sprFG = new g.FilledRect({
                scene: _this,
                width: g.game.width,
                height: g.game.height,
                cssColor: "red",
                opacity: 0
              });

              _this.append(sprFG); //スタート・終了表示用


              var stateSpr = new g.FrameSprite({
                scene: _this,
                src: _this.asset.getImageById("start"),
                width: 800,
                height: 250,
                x: (g.game.width - 800) / 2,
                y: (g.game.height - 250) / 2,
                frames: [0, 1],
                frameNumber: 0,
                parent: _this
              });
              var btnReset;
              var btnRanking;

              if (param.isAtsumaru || isDebug) {
                // リセットボタン
                btnReset = new Button_1.Button(_this, ["リセット"], 1000, 520, 130);
                btnReset.scale(2.0);
                btnReset.modified();

                _this.append(btnReset);

                btnReset.pushEvent = function () {
                  reset();
                }; // ランキングボタン


                btnRanking = new Button_1.Button(_this, ["ランキング"], 1000, 400, 130);
                btnRanking.scale(2.0);
                btnRanking.modified();

                _this.append(btnRanking);

                btnRanking.pushEvent = function () {
                  //スコアを入れ直す応急措置
                  //window.RPGAtsumaru.scoreboards.setRecord(1, g.game.vars.gameState.score).then(() => {
                  window.RPGAtsumaru.scoreboards.display(1); //});
                }; //コンフィグ表示ボタン


                var btnConfig = new g.Sprite({
                  scene: _this,
                  src: _this.asset.getImageById("config"),
                  x: 1200,
                  scaleX: 2,
                  scaleY: 2.0,
                  touchable: true,
                  parent: _this
                });
                btnConfig.onPointDown.add(function () {
                  if (config.state & 1) {
                    config.show();
                  } else {
                    config.hide();
                  }
                });
              } //コンフィグ画面


              var config = new Config_1.Config(_this, 780, 80);

              _this.append(config);

              config.bg = bg;
              config.hide();

              config.bgmEvent = function (num) {
                bgm.changeVolume(0.6 * num);
              }; //効果音再生


              _this.playSound = function (name) {
                _this.assets[name].play().changeVolume(config.volumes[1]);
              };

              var updateHandler = function updateHandler() {
                if (time <= 0) {
                  // RPGアツマール環境であればランキングを表示します
                  if (param.isAtsumaru) {
                    var boardId = 1;
                    var board = window.RPGAtsumaru.scoreboards;
                    board.setRecord(boardId, g.game.vars.gameState.score).then(function () {//board.display(boardId);
                    });
                  } //終了表示


                  stateSpr.frameNumber = 1;
                  stateSpr.modified();
                  stateSpr.show();
                  btnReset === null || btnReset === void 0 ? void 0 : btnReset.show();
                  btnRanking === null || btnRanking === void 0 ? void 0 : btnRanking.show();
                  _this.isStart = false;

                  _this.onUpdate.remove(updateHandler);

                  _this.playSound("se_timeup");

                  sprFG.cssColor = "black";
                  sprFG.opacity = 0.3;
                  sprFG.modified();
                } // カウントダウン処理


                time -= 1 / g.game.fps;
                timeLabel.text = "" + Math.ceil(time);
                timeLabel.invalidate(); //ラスト5秒の点滅

                if (time <= 5) {
                  sprFG.opacity = (time - Math.floor(time)) / 3;
                  sprFG.modified();
                }
              }; // スコア追加


              _this.addScore = function (score) {
                if (time < 0) return;
                g.game.vars.gameState.score += score;
                timeline.create(_this).every(function (e, p) {
                  scoreLabel.text = "" + (g.game.vars.gameState.score - Math.floor(score * (1 - p))) + "P";
                  scoreLabel.invalidate();
                }, 500); // スコア表示用のラベル

                var label = new g.Label({
                  scene: _this,
                  text: "+" + score,
                  font: fontRed,
                  fontSize: 32,
                  x: 750,
                  y: 60,
                  width: 410,
                  widthAutoAdjust: false,
                  textAlign: "right",
                  opacity: 0.0,
                  parent: _this
                });
                timeline.create(label).every(function (e, p) {
                  label.opacity = p;
                }, 100).wait(500).call(function () {
                  label.destroy();
                });
              }; //リセット処理


              var reset = function reset() {
                maingame === null || maingame === void 0 ? void 0 : maingame.destroy();
                maingame = new MainGame_1.MainGame();
                base.append(maingame);
                time = timeLimit;
                timeLabel.text = "" + time;
                timeLabel.invalidate();
                g.game.vars.gameState.score = 0;
                scoreLabel.text = "0";
                scoreLabel.invalidate();
                stateSpr.frameNumber = 0;
                stateSpr.modified();
                stateSpr.show();

                _this.setTimeout(function () {
                  stateSpr.hide();
                }, 1000);

                btnReset === null || btnReset === void 0 ? void 0 : btnReset.hide();
                btnRanking === null || btnRanking === void 0 ? void 0 : btnRanking.hide();

                _this.playSound("se_start");

                _this.isStart = true;
                sprFG.opacity = 0;
                sprFG.cssColor = "red";
                sprFG.modified();

                _this.onUpdate.add(updateHandler);
              };

              reset();
            };
          });

          return _this;
        }

        return MainScene;
      }(g.Scene);

      exports.MainScene = MainScene;
    }, {
      "./Button": 6,
      "./Config": 7,
      "./MainGame": 15,
      "@akashic-extension/akashic-timeline": 5
    }],
    17: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics12 = function extendStatics(d, b) {
          _extendStatics12 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics12(d, b);
        };

        return function (d, b) {
          _extendStatics12(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Player = void 0; //プレイヤークラス

      var Player =
      /** @class */
      function (_super) {
        __extends(Player, _super);

        function Player(mainGame) {
          var _this = this;

          var scene = mainGame.scene;
          _this = _super.call(this, {
            scene: scene,
            src: scene.asset.getImageById("player"),
            x: 128,
            y: 128,
            width: 128,
            height: 128,
            frames: [0, 1, 0, 2],
            frameNumber: 0,
            interval: 100,
            parent: mainGame
          }) || this;
          _this.werpon = new g.FrameSprite({
            scene: scene,
            src: scene.asset.getImageById("werpon"),
            x: _this.width / 2,
            y: _this.height / 2,
            width: 128,
            height: 128,
            frames: [0, 1, 2],
            frameNumber: 0,
            interval: 100,
            parent: _this,
            anchorX: 0.5,
            anchorY: 0.5
          });

          _this.start();

          return _this;
        }

        return Player;
      }(g.FrameSprite);

      exports.Player = Player;
    }, {}],
    18: [function (require, module, exports) {
      // 通常このファイルを編集する必要はありません。ゲームの処理は main.js に記述してください
      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        }); // セッションパラメーター

        param.sessionParameter = {}; // コンテンツが動作している環境がRPGアツマール上かどうか

        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined"; // 乱数生成器

        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数

        var scene = new g.Scene({
          game: g.game
        }); // セッションパラメーターを受け取ってゲームを開始します

        scene.onMessage.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加

            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }

            g.game.popScene();
            main_1.main(param);
          }
        });
        scene.onLoad.add(function () {
          var currentTickCount = 0;
          scene.onUpdate.add(function () {
            currentTickCount++; // 待ち時間を超えた場合はゲームを開始します

            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              main_1.main(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 19
    }],
    19: [function (require, module, exports) {
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.main = void 0;

      var MainScene_1 = require("./MainScene");

      function main(param) {
        var scene = new MainScene_1.MainScene(param);
        g.game.pushScene(scene);
      }

      exports.main = main;
    }, {
      "./MainScene": 16
    }]
  }, {}, [18])(18);
});